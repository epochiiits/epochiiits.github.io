package com.example.world_time

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
